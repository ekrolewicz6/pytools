.. _rdata:

DNS Rdata
=========

.. toctree::

   rdata-types
   rdata-class
   rdata-make
   rdata-subclasses
   rdata-set-classes
   rdata-set-make
