.. _message-make:

Making DNS Messages
-------------------

.. autofunction:: dns.message.from_file
.. autofunction:: dns.message.from_text
.. autofunction:: dns.message.from_wire
.. autofunction:: dns.message.make_query
.. autofunction:: dns.message.make_response
